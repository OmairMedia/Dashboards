import { Component } from '@angular/core';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'widget',
  templateUrl: './widget.component.html'
})
export class WidgetComponent {
  constructor() {}
}

import { Component } from '@angular/core';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'to-do',
  templateUrl: './todo.component.html'
})
export class TodoComponent {
  constructor() {}
}

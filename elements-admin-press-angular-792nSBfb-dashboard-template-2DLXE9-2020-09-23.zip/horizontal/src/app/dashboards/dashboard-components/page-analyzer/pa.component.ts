import { Component } from '@angular/core';
@Component({
  selector: 'app-pa',
  templateUrl: './pa.component.html'
})
export class PageAnalyzerComponent {
  constructor() {}
}

import { Component } from '@angular/core';
@Component({
  selector: 'app-activity-timeline',
  templateUrl: './activity.component.html'
})
export class ActivityComponent {
  constructor() {}
}

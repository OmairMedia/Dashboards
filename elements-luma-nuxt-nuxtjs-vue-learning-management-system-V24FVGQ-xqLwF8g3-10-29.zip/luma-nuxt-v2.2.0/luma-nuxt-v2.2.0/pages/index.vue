<script>
  import Index from '~/pages/_layout/home'
  export default {
    extends: Index,
    layout: 'fixed'
  }
</script>

import Vue from 'vue'

import {FmvAvatar} from 'fmv-avatar'

Vue.component('FmvAvatar', FmvAvatar)
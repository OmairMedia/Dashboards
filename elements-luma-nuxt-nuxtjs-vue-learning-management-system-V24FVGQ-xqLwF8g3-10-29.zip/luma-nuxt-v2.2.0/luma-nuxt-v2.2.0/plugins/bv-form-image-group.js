import Vue from 'vue'

import {BvFormImageGroup} from 'bv-form-image-group'

Vue.component('BvFormImageGroup', BvFormImageGroup)
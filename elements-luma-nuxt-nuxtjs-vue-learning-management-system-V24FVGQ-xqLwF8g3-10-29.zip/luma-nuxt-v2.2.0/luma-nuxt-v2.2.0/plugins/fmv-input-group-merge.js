import Vue from 'vue'

import {FmvInputGroupMerge} from 'fmv-input-group-merge'

Vue.component('FmvInputGroupMerge', FmvInputGroupMerge)